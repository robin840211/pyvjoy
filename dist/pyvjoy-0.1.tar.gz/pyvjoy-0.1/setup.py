from setuptools import setup

setup(
    name='pyvjoy',
    version='0.1',
    scripts=['vjoydevice']
)